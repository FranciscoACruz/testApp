//
//  HomeVC.swift
//  testApp
//
//  Created by Alex Cruz on 27/09/22.
//

import UIKit

class HomeVC:  UIViewController, UITableViewDelegate, UITableViewDataSource {
    var userList : Array<User> = Array<User>()
    var pageNo : UInt = 1
    var itemPerPage : UInt = 30
    
    @IBOutlet var userListTableV: UITableView!
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        userListTableV.dataSource = self
        userListTableV.delegate = self
        requestUsers()
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "UserDataCell", for: indexPath) as! userCell
        cell.setData(user: userList[indexPath.row])
        return cell
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return userList.count
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        tableView.deselectRow(at: indexPath, animated: true)
    }
    
    func tableView(_ tableView: UITableView, willDisplay cell: UITableViewCell, forRowAt indexPath: IndexPath) {
        if(indexPath.row == self.userList.count - 3) {
            requestUsers()
        }
    }
    
    func requestUsers() {
        if(!RestAPI.shared.isOnRequest()) {
            RestAPI.shared.getUsersList(pageNo: pageNo, itemCnt: itemPerPage,
                                           onSuccess: successfullyRetrivedUserList(users:),
                                           onFail: failedToRetriveUserList(err:))
        }
    }
    
    func applyFilter() {
        userList.removeAll()
        RestImg.shared.cleanCache()
        
        pageNo = 1
        RestAPI.shared.resetSeed()
        
        userListTableV.reloadData()
        requestUsers()
    }
    
    func successfullyRetrivedUserList(users : Array<User>) {
        pageNo += 1
        userList.append(contentsOf: users)
        userListTableV.reloadData()
        userListTableV.isHidden = false
    }
    
    func failedToRetriveUserList(err : Error) {
        print(err.localizedDescription)
        userListTableV.isHidden = true
    }
    
    @IBAction func retryToLoad(_ sender: UIButton) {
        requestUsers()
    }
    
    override func didReceiveMemoryWarning() {
        RestImg.shared.cleanCache()
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if(segue.identifier == "UserDetailVC") {
            (segue.destination as! UserDetailVC).user = userList[userListTableV.indexPathForSelectedRow!.row]
        }
        if(segue.identifier == "filterView") {
            (segue.destination as! FilterVC).applyFilter = applyFilter
        }
    }
}
