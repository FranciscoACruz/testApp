//
//  UserDetailVC.swift
//  testApp
//
//  Created by Alex Cruz on 27/09/22.
//

import UIKit
import MapKit

class UserDetailVC: UIViewController {
    var user : User!
    
    @IBOutlet weak var locationHeader: UILabel!
    @IBOutlet weak var contactHeader: UILabel!
    @IBOutlet var profileImageV: UIImageView!
    
    @IBOutlet var nameLabel: UILabel!
    @IBOutlet var locationLabel: UILabel!
    @IBOutlet var detailLabel: UILabel!
    
    @IBOutlet var locationMapV: MKMapView!
    
    @IBOutlet var mailLabel: UILabel!
    @IBOutlet var phoneNoLabel: UILabel!
    @IBOutlet var mobileNoLabel: UILabel!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        title = "\(user!.name.first.makeFirstCharUpper()) \(user!.name.last.makeFirstCharUpper())"
        
        // Thumbnail image
        RestImg.shared.requestImage(url: user!.profilePic.original) { (image) in
            self.profileImageV.image = image
        }
        
        locationHeader.layer.cornerRadius = 8
        locationHeader.layer.masksToBounds = true
        locationHeader.layer.backgroundColor = UIColor.lightGray.cgColor
        
        contactHeader.layer.cornerRadius = 8
        contactHeader.layer.masksToBounds = true
        contactHeader.layer.backgroundColor = UIColor.lightGray.cgColor
        
        profileImageV.layer.cornerRadius = self.profileImageV.frame.width / 2.0
        profileImageV.layer.masksToBounds = true
        
        // Set date format
        let formatter = DateFormatter()
        formatter.dateStyle = .medium
        
        // fetch data
        nameLabel.text = self.title
        locationLabel.text = "\(user!.location.city), \(user!.location.state)"
        detailLabel.text = "\(user!.gender.rawValue.lowercased().makeFirstCharUpper()) (\(user!.bdy.age)) \(formatter.string(from: user!.bdy.birthDate))"
        
        phoneNoLabel.text = user!.phoneNo
        mobileNoLabel.text = user!.cellNo
        mailLabel.text = user!.email
    }
    
    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)
        
        let userLocation = MKPointAnnotation()
        userLocation.coordinate = CLLocationCoordinate2DMake(user!.location.coordinates.lat, user!.location.coordinates.lon)
        userLocation.title = "User Location"
        locationMapV.setCenter(userLocation.coordinate, animated: true)
        locationMapV.showAnnotations([userLocation,], animated: true)
    }
}

