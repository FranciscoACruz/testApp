//
//  SplashVC.swift
//  testApp
//
//  Created by Alex Cruz on 27/09/22.
//

import UIKit

class SplashVC: Base {
    private var timer : Timer?
    private weak var firstView: UIViewController!
    
    override func viewDidLoad() {
        super.viewDidLoad()
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        Utils.lottieAnimation(view: self.view)
        Utils.playSound()
    
        timer = Timer.scheduledTimer(withTimeInterval: 5.0, repeats: false, block: { timer in
            self.stopTimer()
        })
    }
    
    func stopTimer(){
        if timer != nil {
            timer!.invalidate()
            timer = nil
            self.showHome()
        }
    }
    
    @objc func showHome(){
        if !UserDefaults.standard.bool(forKey: "firstOpen"){
            self.openController(storyboard:"Main", view: "HomeView")
        }
        
    }

}

