//
//  MainVC.swift
//  testApp
//
//  Created by Alex Cruz on 27/09/22.
//

import UIKit

class MainVC: UINavigationController {

    override func viewDidLoad() {
        super.viewDidLoad()
    }
}
