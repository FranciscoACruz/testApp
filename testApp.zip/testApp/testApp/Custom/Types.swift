//
//  Types.swift
//  testApp
//
//  Created by Alex Cruz on 27/09/22.
//

typealias JsonObj = Dictionary<String, Any?>
typealias JsonArr = Array<JsonObj>
typealias StrDict = Dictionary<String, String>
