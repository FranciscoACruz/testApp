//
//  userCell.swift
//  testApp
//
//  Created by Alex Cruz on 27/09/22.
//

import UIKit

class userCell: UITableViewCell {

    @IBOutlet var userContentCell: UIView!
    @IBOutlet var profileImageV: UIImageView!
    @IBOutlet var nameLabel: UILabel!
    @IBOutlet var infoLabel: UILabel!
    
    override func awakeFromNib() {
        super.awakeFromNib()
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)
    }
    
    func setData(user : User) {
        let formatter = DateFormatter()
        formatter.dateStyle = .short
        
        self.backgroundColor = .systemCyan
        
        self.profileImageV.image = UIImage(named: "ic_user")
        self.profileImageV.layer.cornerRadius = self.profileImageV.frame.width / 2.0
        self.profileImageV.layer.masksToBounds = true
        
        self.nameLabel.text = "\(user.name.first.makeFirstCharUpper()) \(user.name.last.makeFirstCharUpper())"
        self.infoLabel.text = "\(user.gender.rawValue.lowercased().makeFirstCharUpper()) (\(user.bdy.age)) \(formatter.string(from: user.bdy.birthDate))"
        
        RestImg.shared.requestImage(url: user.profilePic.thumbnail) { (image) in
            self.profileImageV.image = image
        }
    }
}
