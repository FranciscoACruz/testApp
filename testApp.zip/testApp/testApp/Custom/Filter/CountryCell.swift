//
//  CountryCell.swift
//  testApp
//
//  Created by Alex Cruz on 27/09/22.
//

import UIKit

class CountryCell: UITableViewCell {

    @IBOutlet var countryNameLabel: UILabel!
    @IBOutlet var checkedLabel: UILabel!
    
    override func awakeFromNib() {
        super.awakeFromNib()
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

    }

}
