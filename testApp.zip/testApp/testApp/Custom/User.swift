//
//  User.swift
//  testApp
//
//  Created by Alex Cruz on 27/09/22.
//

import Foundation

// User Object
struct User {
    let name : Name
    
    let gender : Gender
    let location : Location
    let email : String
    
    let bdy : Bdy
    
    let phoneNo : String
    let cellNo : String
    
    let profilePic : ProfilePicture
    
    init(dict : JsonObj) {
        name = Name(dict: dict["name"] as! StrDict)
        gender = Gender.parse(rawValue: dict["gender"] as! String) ?? Gender.other
        location = Location(dict: dict["location"] as! JsonObj)
        
        email = dict["email"] as? String ?? ""
        
        bdy = Bdy(dict: dict["dob"] as! JsonObj)
        
        phoneNo = dict["phone"] as? String ?? ""
        cellNo = dict["cell"] as? String ?? ""
        
        profilePic = ProfilePicture(dict: dict["picture"] as! StrDict)
    }
}
