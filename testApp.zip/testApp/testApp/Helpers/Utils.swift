//
//  Utils.swift
//  testApp
//
//  Created by Alex Cruz on 26/09/22.
//

import AVFoundation
import UIKit
import Lottie

var player: AVAudioPlayer?

class Utils {
    internal static func playSound(){
        guard let url = Bundle.main.url(forResource: "splash_Intro", withExtension: "mp3") else { return }

        do {
            try AVAudioSession.sharedInstance().setCategory(.playback, mode: .default)
            try AVAudioSession.sharedInstance().setActive(true)
            
            player = try AVAudioPlayer(contentsOf: url, fileTypeHint: AVFileType.mp3.rawValue)

            guard let player = player else { return }

            player.play()
            
            Timer.scheduledTimer(timeInterval: 4.5, target: self, selector: #selector(pauseAudio), userInfo: nil, repeats: false)
        } catch let error {
            print(error.localizedDescription)
        }
    }
    
    @objc static func pauseAudio() {
        guard let audioPlayer = player else { return }
        audioPlayer.setVolume(0.8, fadeDuration: 1.0)
        audioPlayer.stop()
        
    }
    
    let animationView = AnimationView()
    static let screenWidth = UIScreen.main.bounds.size.width
    static let screenHeight = UIScreen.main.bounds.size.height
    static let screenSize = UIScreen.main.bounds.size
  
    static func lottieAnimation(view:UIView){
        let starAnimationView = AnimationView(name: "splash")
        
        let starAnimation = Animation.named("splash")
        let rect = CGRect(x: 0, y: 0, width:
                            screenWidth, height: screenHeight)

        let adjusted = increaseRect(rect: rect, byPercentage: 0.8)
        
        starAnimationView.animation = starAnimation
        starAnimationView.frame = adjusted
        starAnimationView.center = view.center
        
        view.addSubview(starAnimationView)
        
        starAnimationView.play { (finished) in
            view.inputAccessoryViewController?.navigationController?.interactivePopGestureRecognizer!.isEnabled = false
        }
    }
    
    static func increaseRect(rect: CGRect, byPercentage percentage: CGFloat) -> CGRect {
        let startWidth = rect.width
        let startHeight = rect.height
        let adjustmentWidth = (startWidth * percentage) / 6
        let adjustmentHeight = (startHeight * percentage) / 6
        return rect.insetBy(dx: -adjustmentWidth, dy: -adjustmentHeight)
    }
    
}
