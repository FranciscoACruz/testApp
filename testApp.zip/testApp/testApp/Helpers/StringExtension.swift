//
//  StringExtension.swift
//  testApp
//
//  Created by Alex Cruz on 27/09/22.
//

import UIKit

extension String {
    func makeFirstCharUpper() -> String {
        return prefix(1).uppercased() + self.lowercased().dropFirst()
    }
}
