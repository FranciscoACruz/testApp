//
//  Base.swift
//  testApp
//
//  Created by Alex Cruz on 26/09/22.
//

import UIKit
import Foundation
import AVFoundation


class Base: UIViewController {
    override func viewDidLoad() {
        super.viewDidLoad()
    }
    
    func openController(storyboard:String, view:String){
        let rvc = UIStoryboard(name: storyboard, bundle: nil).instantiateViewController(withIdentifier: view)
        
        let vc = UINavigationController(rootViewController: rvc)
        vc.modalPresentationStyle = .overFullScreen
        present(vc, animated: true, completion: nil)
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
    }
    
    @objc func goBack() {
       self.navigationController?.popViewController(animated: true)
    }
}
