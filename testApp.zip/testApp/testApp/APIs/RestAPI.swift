//
//  RestAPI.swift
//  testApp
//
//  Created by Alex Cruz on 27/09/22.
//

import UIKit

class RestAPI {
    static let shared = RestAPI()
    private init() {}
    
    private var seed = ""
    private var onRequest = false
    
    private var genderFilter = ""
    private var nationalitiesFilter = ""
    
    func getUsersList(pageNo : UInt, itemCnt : UInt,
                      onSuccess : @escaping ((Array<User>)->Void), onFail : @escaping ((Error)->Void)) {
        self.onRequest = true
        var queries = Dictionary<String, String>()
        
        queries[PARAM_PAGE] = String(pageNo)
        queries[PARAM_ITEM_PER_PAGE] = String(itemCnt)
        
        if(!seed.isEmpty) {
            queries[PARAM_SEED] = seed
        }
        
        if(!genderFilter.isEmpty) {
            queries[PARAM_FILTER_GENDER] = genderFilter
        }
        if(!nationalitiesFilter.isEmpty) {
            queries[PARAM_FILTER_NATIONALITY] = nationalitiesFilter
        }
        
        var request = URLRequest(url: makeRequestURL(url: BASE_URL, query: makeQuery(dict: queries)))
        request.httpMethod = "GET"
        
        let task = URLSession.shared.dataTask(with: request) { (data, resp, err) in
            if(err != nil) {
                DispatchQueue.main.async {
                    self.onRequest = false
                    onFail(err!)
                }
            } else {
                do {
                    let result = try JSONSerialization.jsonObject(with: data!, options: []) as! JsonObj
                    self.seed = (result["info"] as! JsonObj)["seed"] as? String ?? ""
                    self.onRequest = false
                    
                    DispatchQueue.main.async {
                        onSuccess((result["results"] as! Array<JsonObj>).map {
                            User(dict: $0)
                        })
                    }
                }
                catch let err {
                    DispatchQueue.main.async {
                        self.onRequest = false
                        onFail(err)
                    }
                }
            }
        }
        
        task.resume()
    }
    
    private func makeQuery(dict : Dictionary<String, String>) -> String {
        return dict.reduce("") {
            return $0 + "\($1.key)=\($1.value)&"
        }
    }
    
    private func makeRequestURL(url : String, query : String) -> URL {
        return URL(string: url + "?" + query)!
    }
    
    func resetSeed() {
        seed = ""
    }
    
    func isOnRequest() -> Bool {
        return onRequest
    }
    
    func setGenderFilter(gender : Gender) {
        switch gender {
        case .male:
            genderFilter = "male"
        
        case .female:
            genderFilter = "female"
            
        case .other:
            genderFilter = ""
        }
    }
    
    func setNationalitiesFilter(nationalities : Array<String>) {
        nationalitiesFilter = nationalities.reduce(""){return $0 + "\($1),"}
    }
    
    func resetAllFilter() {
        nationalitiesFilter = ""
        genderFilter = ""
    }
    
    func getSupportedNationalities() -> [String] {
        let countries = "AU, BR, CA, CH, DE, DK, ES, FI, FR, GB, IE, IR, NO, NL, NZ, TR, US"
        return countries.components(separatedBy: ", ")
    }
}
