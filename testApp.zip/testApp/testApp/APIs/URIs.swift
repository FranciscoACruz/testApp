//
//  URIs.swift
//  testApp
//
//  Created by Alex Cruz on 27/09/22.
//

import UIKit

let BASE_URL = "https://randomuser.me/api/"

let PARAM_SEED = "seed"
let PARAM_PAGE = "page"
let PARAM_ITEM_PER_PAGE = "results"

let PARAM_FILTER_GENDER = "gender"
let PARAM_FILTER_NATIONALITY = "nat"
