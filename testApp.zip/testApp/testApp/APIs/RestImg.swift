//
//  RestImg.swift
//  testApp
//
//  Created by Alex Cruz on 27/09/22.
//

import UIKit

class RestImg {
    static let shared = RestImg()
    private init() {}
    
    private var images : Dictionary<String, UIImage> = Dictionary<String, UIImage>()
    
    func requestImage(url : URL, onSuccess : @escaping ((UIImage)->Void)) {
        if(self.images[url.absoluteString] != nil) {
            onSuccess(self.images[url.absoluteString]!)
        } else {
            let task = URLSession.shared.dataTask(with: url) { (data, resp, err) in
                if(err == nil) {
                    DispatchQueue.main.async() {
                        self.images[url.absoluteString] = UIImage(data: data!)
                        onSuccess(self.images[url.absoluteString]!)
                    }
                }
            }
            task.resume()
        }
    }
    
    func cleanCache() {
        images.removeAll()
    }
}
